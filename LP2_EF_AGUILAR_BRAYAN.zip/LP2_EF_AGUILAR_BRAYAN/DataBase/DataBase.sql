DROP DATABASE IF EXISTS bd_202336496;
CREATE DATABASE IF NOT EXISTS bd_202336496;

USE bd_202336496;

CREATE TABLE usuarios (
    idusuario INT AUTO_INCREMENT PRIMARY KEY,
    nombreusuario VARCHAR(50) NOT NULL,
    apellidousuario VARCHAR(50) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL, 
    fechanacimiento DATE NOT NULL
);

CREATE TABLE categorias (
    idcategoria INT AUTO_INCREMENT PRIMARY KEY,
    nombrecategoria VARCHAR(50) NOT NULL
);

CREATE TABLE productos (
    idproducto INT AUTO_INCREMENT PRIMARY KEY,
    nombreproducto VARCHAR(100) NOT NULL,
    descripcionproducto TEXT,
    precio DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL,
    idcategoria INT,
    fechacreacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fechaactualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (idcategoria) REFERENCES categorias(idcategoria)
);

INSERT INTO categorias (nombrecategoria)
VALUES ('LACTEOS'), ('ABARROTES'), ('BEBIDAS'), ('SNACKS');

INSERT INTO productos (nombreproducto, descripcionproducto, precio, stock, idcategoria)
VALUES 
('Leche gloria', 'Leche evaporada Gloria', 2.50, 10, 1),
('Arroz sureño', 'Arroz de alta calidad', 4.50, 20, 2),
('Azúcar', 'Azúcar blanca granulada', 1.20, 50, 3),
('Aceite de oliva', 'Aceite de oliva extra virgen', 5.00, 15, 4),
('Pasta', 'Pasta de trigo', 3.00, 30, 1),
('Sal', 'Sal de mesa', 0.50, 100, 3),
('Harina', 'Harina de trigo', 2.00, 25, 3),
('Frijoles', 'Frijoles negros enlatados', 1.80, 40, 4),
('Lentejas', 'Lentejas secas', 2.20, 35, 2),
('Jugo de naranja', 'Jugo de naranja natural', 3.50, 20, 2),
('Galletas', 'Galletas de chocolate', 2.75, 60, 4),
('Cereal', 'Cereal de desayuno', 3.80, 45, 3),
('Yogur', 'Yogur natural', 1.90, 50, 4),
('Mantequilla', 'Mantequilla sin sal', 3.20, 15, 1),
('Chocolate', 'Chocolate en tableta', 2.40, 40, 1);

INSERT INTO usuarios (nombreusuario, apellidousuario, correo, contrasena, fechanacimiento)
VALUES 
('Juan', 'Pérez', 'juan.perez@example.com', 'contrasenaSegura123', '1990-05-15');

SELECT * FROM usuarios;
SELECT * FROM categorias;
SELECT * FROM productos;

SELECT idProducto, nombreProducto, fechaCreacion, fechaActualizacion 
FROM productos;