package com.sistemacrud.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="usuarios")
public class Usuario {
	@Id
	private int idusuario;
    private String nombreusuario;
    private String apellidousuario;
    private String correo;
    private String contrasena;
    private String fechanacimiento;
}
