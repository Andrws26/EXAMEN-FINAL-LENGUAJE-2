package com.sistemacrud.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="productos")
public class Producto {
	@Id
	private int idproducto;
    private String nombreproducto;
    private String descripcionproducto;
    private double precio;
    private int stock;
    private int idcategoria;
    private String fechacreacion;
    private String fechaactualizacion;
    
    @ManyToOne
    @JoinColumn(name = "idcategoria", insertable = false, updatable = false)
    private Categoria objCategoria;
}
