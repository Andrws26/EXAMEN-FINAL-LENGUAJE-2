package com.sistemacrud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import com.sistemacrud.interfaces.ICategoriaRepository;
import com.sistemacrud.interfaces.IProductoRepository;
import com.sistemacrud.model.Producto;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class CrudController {
	
	@Autowired
	private ICategoriaRepository repoCate;
	
	@Autowired
	private IProductoRepository repoProd;
	
	@GetMapping("/listar")
	public String listarProductos(Model model ) {
		model.addAttribute("lstSolicitudes", repoProd.findAll());
        return "listarproductos";
	}
	
	@GetMapping("/cargar")
	public String cargarCrudProd(Model model) {
		
		model.addAttribute("producto", new Producto());
		model.addAttribute("lstCategorias", repoCate.findAll());
		model.addAttribute("lstProductos", repoProd.findAll());
		
		return "registrarproducto";
	}
	
	@GetMapping("/catalogo")
	public String cargarCatalogo(Model model) {
		model.addAttribute("lstCategorias", repoCate.findAll());
		model.addAttribute("lstProductos", repoProd.findAll());	
		return "catalogo";
	}
	
	@PostMapping("/filtrar")
	public String filtrarCatalogo(@RequestParam int idcategoria, Model model) {
		model.addAttribute("lstCategorias", repoCate.findAll());
		if (idcategoria == 0)
			model.addAttribute("lstProductos", repoProd.findAll());
		else
			model.addAttribute("lstProductos", repoProd.findByIdcategoria(idcategoria));
		return "catalogo";
	}
	
	
	
	@PostMapping("/grabar")
	public String grabarCrudProd(Model model, @ModelAttribute Producto producto) {
		
		System.out.println(producto);
		repoProd.save(producto);
		
		return "redirect:/cargar";
	}
	
	@GetMapping("/editar/{idproducto}")
	public String editar(@PathVariable int idproducto, Model model) {
		Producto p = repoProd.findById(idproducto).get();
		model.addAttribute("producto", p);
		
		model.addAttribute("lstCategorias", repoCate.findAll());

		model.addAttribute("lstProductos", repoProd.findAll());
		return "crudproductos";
	}
	
	
	
}
