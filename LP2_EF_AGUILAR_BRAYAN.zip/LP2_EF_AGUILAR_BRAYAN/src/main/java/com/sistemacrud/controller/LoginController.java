package com.sistemacrud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sistemacrud.interfaces.IUsuarioRepository;
import com.sistemacrud.model.Usuario;



@Controller
public class LoginController {
	
	@Autowired
	private IUsuarioRepository repoUsu;
	
	@GetMapping("/login")
	public String cargarLogin() {
		return "login";
	}
	
	@PostMapping("/login")
	public String leerLogin(@RequestParam String correo,
			@RequestParam String contrasena, Model model) {
		System.out.println(correo + " " + contrasena);
		
		Usuario u = repoUsu.findByCorreoAndContrasena(correo, contrasena);
		
		if (u != null) {
			// mensaje "Bienvenido"
			model.addAttribute("usuario", u.getNombreusuario());
			model.addAttribute("cssmensaje","alert alert-success");
			return "listarproductos";
		} else {
			//mensaje "Error"
			model.addAttribute("mensaje","Usuario o clave incorrecto");
			model.addAttribute("cssmensaje", "alert alert-danger");
			return "login";
		}
	}
	
	
	@GetMapping("/registrar")
	public String registrarCuenta(Model model) {
		model.addAttribute("usuario", new Usuario());
		return "registrar";
	}
	
	@PostMapping("/registrar")
	public String leerRegistrar(Model model, @ModelAttribute Usuario usuario) {
		System.out.println(usuario);
		
		try {
			repoUsu.save(usuario);
			model.addAttribute("mensaje", "Registro OK");
			model.addAttribute("cssmensaje","alert alert-success");
		} catch (Exception e) {
			model.addAttribute("mensaje","Error al registrar" + e.getMessage());
			model.addAttribute("cssmensaje", "alert alert-danger");
		}
		return "registrar";
	}
	
}