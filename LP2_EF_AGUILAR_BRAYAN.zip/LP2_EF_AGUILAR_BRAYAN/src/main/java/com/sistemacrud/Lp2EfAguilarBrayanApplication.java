package com.sistemacrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lp2EfAguilarBrayanApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lp2EfAguilarBrayanApplication.class, args);
	}

}
